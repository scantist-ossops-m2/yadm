# yadm - Yet Another Dotfiles Manager [![Build Status](https://travis-ci.org/TheLocehiliosan/yadm.svg?branch=master)](https://travis-ci.org/TheLocehiliosan/yadm)

Features, usage, examples and installation instructions can be found on the [website](https://thelocehiliosan.github.io/yadm/).

[https://thelocehiliosan.github.io/yadm/](https://thelocehiliosan.github.io/yadm/)

<!-- vim: set spell lbr : -->
